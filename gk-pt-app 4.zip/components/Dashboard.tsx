import React from 'react';
import { Routine, WorkoutSession } from '../types';

interface DashboardProps {
  routines: Routine[];
  history: WorkoutSession[];
  onSelectRoutine: (routine: Routine) => void;
  onNavigateToImport: () => void;
  onNavigateToHistory: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  routines, 
  history,
  onSelectRoutine, 
  onNavigateToImport,
  onNavigateToHistory
}) => {
  const today = new Date().toLocaleDateString(undefined, { 
    weekday: 'long', 
    month: 'short', 
    day: 'numeric' 
  });

  const getLastTrainedDate = (routineId: string) => {
    const lastSession = history.find(s => s.routineId === routineId);
    if (!lastSession) return null;
    return new Date(lastSession.date).toLocaleDateString(undefined, {
      month: 'short',
      day: 'numeric'
    });
  };

  const handleShare = async () => {
    const shareData = {
      title: 'GK PT App',
      text: 'Check out my Gym Workout Tracker!',
      url: window.location.href,
    };

    if (navigator.share && navigator.canShare && navigator.canShare(shareData)) {
      try {
        await navigator.share(shareData);
      } catch (err) {
        console.error('Share failed:', err);
      }
    } else {
      const subject = encodeURIComponent('GK PT Workout App Link');
      const body = encodeURIComponent(`Here is the link to access the workout app: ${window.location.href}`);
      window.location.href = `mailto:?subject=${subject}&body=${body}`;
    }
  };

  return (
    <div className="flex flex-col gap-6 p-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex justify-between items-start mb-2">
        <div>
          <h1 className="text-3xl font-black italic tracking-tighter text-white uppercase leading-none">GK <span className="text-neon neon-glow">PT</span></h1>
          <p className="text-neon font-bold text-[10px] uppercase tracking-widest mt-1 opacity-80">{today}</p>
        </div>
        <div className="flex gap-2">
          <button 
            onClick={handleShare}
            className="w-12 h-12 rounded-full bg-surface flex items-center justify-center border border-gray-800 text-gray-400 hover:text-neon transition-all active:scale-90"
            title="Share App"
          >
            <i className="fas fa-share-nodes text-xl"></i>
          </button>
          <button 
            onClick={onNavigateToHistory}
            className="w-12 h-12 rounded-full bg-surface flex items-center justify-center border border-gray-800 text-gray-400 hover:text-neon transition-all active:scale-90"
            title="Workout History"
          >
            <i className="fas fa-history text-xl"></i>
          </button>
        </div>
      </header>

      <section>
        <div className="flex justify-between items-end mb-4 px-1">
          <h2 className="text-xs uppercase tracking-widest text-gray-500 font-black">Training Programs</h2>
          <span className="text-[10px] text-gray-600 font-bold uppercase italic">3-Day Cycle</span>
        </div>
        
        <div className="flex flex-col gap-4">
          {routines.length > 0 ? (
            routines.map((routine) => {
              const lastTrained = getLastTrainedDate(routine.id);
              return (
                <button
                  key={routine.id}
                  onClick={() => onSelectRoutine(routine)}
                  className="group relative flex flex-col items-start p-6 bg-surface border border-gray-800 rounded-2xl text-left transition-all active:scale-[0.98] hover:border-neon/50"
                >
                  <div className="absolute right-6 top-6 w-10 h-10 rounded-full bg-gray-900 border border-gray-800 flex items-center justify-center group-hover:bg-neon group-hover:text-black transition-colors">
                    <i className="fas fa-play text-sm ml-0.5"></i>
                  </div>
                  
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="text-xl font-black text-white group-hover:text-neon transition-colors uppercase italic">{routine.name}</h3>
                    {lastTrained && (
                      <span className="bg-neon/10 text-neon text-[8px] font-black px-2 py-0.5 rounded-full border border-neon/20 uppercase">
                        Last: {lastTrained}
                      </span>
                    )}
                  </div>
                  
                  <p className="text-gray-500 text-xs font-bold uppercase tracking-tight">
                    {routine.exercises.length} Exercises • Full Body
                  </p>
                  
                  <div className="mt-4 flex flex-wrap gap-2">
                    {routine.exercises.slice(0, 3).map((ex, i) => (
                      <span key={i} className="text-[9px] font-black uppercase px-2 py-1 bg-black/40 rounded border border-gray-800 text-gray-400">
                        {ex.name}
                      </span>
                    ))}
                    {routine.exercises.length > 3 && (
                      <span className="text-[9px] font-black uppercase px-2 py-1 text-gray-600">+{routine.exercises.length - 3}</span>
                    )}
                  </div>
                </button>
              );
            })
          ) : (
            <div className="flex flex-col items-center justify-center py-12 px-6 bg-surface/50 border-2 border-dashed border-gray-800 rounded-3xl text-center">
              <i className="fas fa-dumbbell text-4xl text-gray-700 mb-4"></i>
              <p className="text-gray-400 font-bold text-sm mb-6 uppercase tracking-tight">Program Data Missing</p>
              <button
                onClick={onNavigateToImport}
                className="w-full py-4 bg-neon text-black font-black uppercase tracking-widest rounded-xl shadow-lg shadow-neon/20 active:scale-95 transition-all"
              >
                Set Up Program
              </button>
            </div>
          )}
        </div>
      </section>

      {routines.length > 0 && (
        <button
          onClick={onNavigateToImport}
          className="mt-4 py-4 px-6 border border-gray-800 rounded-xl text-gray-600 font-black uppercase text-[10px] tracking-widest flex items-center justify-center gap-2 hover:bg-surface hover:text-gray-400 transition-all active:scale-95"
        >
          <i className="fas fa-sync-alt"></i>
          Re-Sync Spreadsheet
        </button>
      )}
    </div>
  );
};

export default Dashboard;