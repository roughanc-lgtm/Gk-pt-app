import { Routine, WorkoutSession } from '../types';

const ROUTINES_KEY = 'neonlift_routines';
const HISTORY_KEY = 'neonlift_history';

export const storageService = {
  saveRoutines: (routines: Routine[]) => {
    localStorage.setItem(ROUTINES_KEY, JSON.stringify(routines));
  },

  getRoutines: (): Routine[] => {
    const data = localStorage.getItem(ROUTINES_KEY);
    return data ? JSON.parse(data) : [];
  },

  saveWorkout: (session: WorkoutSession) => {
    const history = storageService.getHistory();
    history.unshift(session);
    localStorage.setItem(HISTORY_KEY, JSON.stringify(history));
  },

  getHistory: (): WorkoutSession[] => {
    const data = localStorage.getItem(HISTORY_KEY);
    return data ? JSON.parse(data) : [];
  },

  clearAll: () => {
    localStorage.removeItem(ROUTINES_KEY);
    localStorage.removeItem(HISTORY_KEY);
  }
};