import { Routine, Exercise } from '../types';

const generateYoutubeLink = (name: string): string => {
  return `https://www.youtube.com/results?search_query=${encodeURIComponent(name + ' exercise form demo')}`;
};

export const parseSpreadsheetData = (text: string): Routine[] => {
  const lines = text.split('\n').map(line => line.trim()).filter(line => line.length > 0);
  const routines: Routine[] = [];
  let currentRoutine: Routine | null = null;

  lines.forEach((line) => {
    // Detect new Day/Routine
    const dayMatch = line.match(/(Day\s*\d+|Routine\s*\d+|Monday|Wednesday|Friday)/i);
    
    if (dayMatch) {
      if (currentRoutine) routines.push(currentRoutine);
      currentRoutine = {
        id: `routine-${Date.now()}-${Math.random()}`,
        name: dayMatch[0],
        exercises: []
      };
      return;
    }

    // Try to parse exercise: Name, Sets, Reps (Comma or Tab separated)
    const parts = line.split(/[,\t|]/).map(p => p.trim());
    
    if (parts.length >= 2 && currentRoutine) {
      const name = parts[0];
      const sets = parseInt(parts[1]) || 3;
      const reps = parts[2] || '10';
      
      const exercise: Exercise = {
        id: `ex-${Date.now()}-${Math.random()}`,
        name,
        sets,
        reps,
        videoUrl: generateYoutubeLink(name)
      };
      currentRoutine.exercises.push(exercise);
    }
  });

  if (currentRoutine) routines.push(currentRoutine);
  return routines;
};

export const getDefaultData = (): string => {
  return `Day 1
Goblet Squat (Half-depth, Dumbbell), 10, 10
Incline Dumbbell Bench Press, 3, 10
Cable Row (Seated or Standing), 3, 10
Step-ups (Weighted, Low Step), 10, 10
Plank Hold, 3, 10

Day 2
Romanian Deadlift (Dumbbell or Barbell), 3, 10
Push-ups (Knee or Full), 3, 10
Single-leg Cable Kickbacks, 3, 10
Landmine Press (One-arm, Barbell in Corner), 3, 10
Pallof Press (Cable or Band), 3, 10

Day 3
Split Squats (Bodyweight or Dumbbell, Partial Range), 3, 10
Overhead Dumbbell Press, 3, 10
Lat Pulldown (Cable), 3, 10
Hip Thrusts (Barbell), 3, 10
Side Plank (Knee Down or Full), 3, 10`;
};