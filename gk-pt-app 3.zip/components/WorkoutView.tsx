
import React, { useState, useEffect } from 'react';
import { Routine, ExerciseResult, SetResult, WorkoutSession } from '../types';

interface WorkoutViewProps {
  routine: Routine;
  onCancel: () => void;
  onFinish: (session: WorkoutSession) => void;
}

const WorkoutView: React.FC<WorkoutViewProps> = ({ routine, onCancel, onFinish }) => {
  const [results, setResults] = useState<ExerciseResult[]>([]);
  const [activeExerciseIndex, setActiveExerciseIndex] = useState(0);
  const [sessionStartTime] = useState(Date.now());

  useEffect(() => {
    // Initialize results structure
    const initialResults: ExerciseResult[] = routine.exercises.map(ex => ({
      exerciseId: ex.id,
      exerciseName: ex.name,
      videoUrl: ex.videoUrl,
      sets: Array.from({ length: ex.sets }, () => ({
        weight: '',
        reps: ex.reps.includes('-') ? ex.reps.split('-')[0] : ex.reps,
        completed: false
      }))
    }));
    setResults(initialResults);
  }, [routine]);

  const handleUpdateSet = (exIndex: number, setIndex: number, field: keyof SetResult, value: string | boolean) => {
    const newResults = [...results];
    const targetSet = newResults[exIndex].sets[setIndex];
    
    if (field === 'completed') {
      targetSet.completed = value as boolean;
    } else {
      (targetSet as any)[field] = value as string;
    }
    
    setResults(newResults);
  };

  const isFinished = results.length > 0 && results.every(ex => ex.sets.every(s => s.completed));

  const handleFinish = () => {
    const session: WorkoutSession = {
      id: `session-${Date.now()}`,
      routineId: routine.id,
      routineName: routine.name,
      date: sessionStartTime,
      results
    };
    onFinish(session);
  };

  const todayStr = new Date(sessionStartTime).toLocaleDateString(undefined, { 
    month: 'short', 
    day: 'numeric' 
  });

  if (results.length === 0) return null;

  return (
    <div className="flex flex-col h-screen bg-dark">
      <header className="sticky top-0 z-10 bg-dark/80 backdrop-blur-lg border-b border-gray-800 p-4 flex justify-between items-center">
        <button onClick={onCancel} className="text-gray-500 font-black uppercase text-[10px] tracking-widest px-2 py-1">Quit</button>
        <div className="text-center">
          <div className="flex items-center justify-center gap-2">
            <h2 className="text-white font-black uppercase tracking-tight text-lg italic">{routine.name}</h2>
            <span className="text-[10px] bg-surface border border-gray-800 text-gray-400 font-black px-1.5 py-0.5 rounded uppercase">
              {todayStr}
            </span>
          </div>
          <div className="h-1 w-32 bg-gray-800 rounded-full mt-2 mx-auto overflow-hidden">
            <div 
              className="h-full bg-neon transition-all duration-300" 
              style={{ width: `${(results.reduce((acc, ex) => acc + ex.sets.filter(s => s.completed).length, 0) / results.reduce((acc, ex) => acc + ex.sets.length, 0)) * 100}%` }}
            ></div>
          </div>
        </div>
        <button 
          onClick={handleFinish}
          className={`font-black uppercase text-[10px] tracking-widest px-3 py-1 rounded transition-colors ${isFinished ? 'bg-neon text-black' : 'text-gray-600 border border-gray-800'}`}
        >
          {isFinished ? 'Finish' : 'Done?'}
        </button>
      </header>

      <div className="flex-1 overflow-y-auto pb-32">
        {results.map((exResult, exIndex) => (
          <div 
            key={exResult.exerciseId} 
            className={`p-4 border-b border-gray-900 transition-opacity ${activeExerciseIndex === exIndex ? 'opacity-100' : 'opacity-40'}`}
            onClick={() => setActiveExerciseIndex(exIndex)}
          >
            <div className="flex justify-between items-start mb-1">
              <div className="flex-1">
                <h3 className="text-lg font-black text-white italic uppercase">{exIndex + 1}. {exResult.exerciseName}</h3>
                {exResult.videoUrl && (
                  <a 
                    href={exResult.videoUrl} 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 mt-1 text-neon/80 hover:text-neon transition-colors"
                  >
                    <i className="fab fa-youtube text-sm"></i>
                    <span className="text-[10px] font-black uppercase tracking-widest">Watch Demo</span>
                  </a>
                )}
              </div>
              <span className="text-[9px] uppercase font-black text-neon bg-neon/5 px-2 py-1 rounded border border-neon/20 whitespace-nowrap">
                Goal: {routine.exercises[exIndex].sets}x{routine.exercises[exIndex].reps}
              </span>
            </div>

            <div className="flex flex-col gap-3 mt-4">
              {exResult.sets.map((set, setIndex) => (
                <div key={setIndex} className={`flex items-center gap-3 p-3 rounded-2xl transition-all duration-300 ${set.completed ? 'bg-neon/10 border border-neon/40 translate-x-1' : 'bg-surface border border-gray-800'}`}>
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-xs ${set.completed ? 'bg-neon text-black' : 'bg-gray-800 text-gray-500'}`}>
                    {setIndex + 1}
                  </div>
                  
                  <div className="flex-1 grid grid-cols-2 gap-2">
                    <div className="relative">
                      <input
                        type="number"
                        placeholder="kg"
                        value={set.weight}
                        onChange={(e) => handleUpdateSet(exIndex, setIndex, 'weight', e.target.value)}
                        className="w-full bg-black/60 border border-gray-700 rounded-xl py-3 px-3 text-white text-center font-black focus:border-neon focus:ring-1 focus:ring-neon outline-none transition-colors"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] text-gray-600 font-black uppercase pointer-events-none">kg</span>
                    </div>
                    <div className="relative">
                      <input
                        type="number"
                        placeholder="reps"
                        value={set.reps}
                        onChange={(e) => handleUpdateSet(exIndex, setIndex, 'reps', e.target.value)}
                        className="w-full bg-black/60 border border-gray-700 rounded-xl py-3 px-3 text-white text-center font-black focus:border-neon focus:ring-1 focus:ring-neon outline-none transition-colors"
                      />
                      <span className="absolute right-3 top-1/2 -translate-y-1/2 text-[9px] text-gray-600 font-black uppercase pointer-events-none">rep</span>
                    </div>
                  </div>

                  <button
                    onClick={() => handleUpdateSet(exIndex, setIndex, 'completed', !set.completed)}
                    className={`w-12 h-12 rounded-xl flex items-center justify-center text-xl transition-all active:scale-90 ${set.completed ? 'bg-neon text-black' : 'bg-gray-800 text-gray-600'}`}
                  >
                    <i className={`fas ${set.completed ? 'fa-check-circle' : 'fa-circle-check'}`}></i>
                  </button>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>

      <div className="fixed bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-dark via-dark/95 to-transparent">
        <button
          onClick={handleFinish}
          className={`w-full py-5 rounded-2xl font-black text-lg uppercase tracking-widest shadow-2xl transition-all active:scale-95 ${isFinished ? 'bg-neon text-black shadow-neon/40' : 'bg-surface border border-gray-800 text-gray-500'}`}
        >
          {isFinished ? 'Log Workout' : 'End Early'}
        </button>
      </div>
    </div>
  );
};

export default WorkoutView;
