
import React, { useState } from 'react';
import { parseSpreadsheetData, getDefaultData } from '../services/parserService';
import { Routine } from '../types';

interface DataImporterProps {
  onImport: (routines: Routine[]) => void;
  onCancel: () => void;
}

const DataImporter: React.FC<DataImporterProps> = ({ onImport, onCancel }) => {
  const [data, setData] = useState('');
  const [error, setError] = useState('');

  const handleImport = () => {
    try {
      const parsed = parseSpreadsheetData(data);
      if (parsed.length === 0) {
        setError('Could not find any routines. Use the format: Day 1, Exercise Name, Sets, Reps');
        return;
      }
      onImport(parsed);
    } catch (err) {
      setError('An error occurred while parsing. Please check your format.');
    }
  };

  const useTemplate = () => {
    setData(getDefaultData());
    setError('');
  };

  return (
    <div className="flex flex-col p-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header className="flex items-center gap-4 mb-8">
        <button onClick={onCancel} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center border border-gray-800 text-white">
          <i className="fas fa-arrow-left"></i>
        </button>
        <h1 className="text-2xl font-black uppercase tracking-tight">Setup <span className="text-neon">Program</span></h1>
      </header>

      <div className="bg-surface p-6 rounded-3xl border border-gray-800 shadow-2xl">
        <p className="text-gray-400 text-sm mb-4 leading-relaxed">
          Paste your spreadsheet rows below or load the recommended 3-day program with 10 reps and 3 sets.
        </p>
        
        <div className="mb-6">
          <label className="block text-[10px] font-black uppercase tracking-widest text-gray-600 mb-2 px-1">Spreadsheet Data</label>
          <textarea
            value={data}
            onChange={(e) => setData(e.target.value)}
            placeholder={`Day 1\nBench Press, 3, 10\nSquats, 3, 5\n...`}
            className="w-full h-64 bg-black border-2 border-gray-800 rounded-2xl p-4 text-white font-mono text-sm focus:border-neon outline-none transition-colors"
          />
        </div>

        {error && (
          <div className="mb-6 p-4 bg-red-500/10 border border-red-500/50 rounded-xl flex items-center gap-3">
            <i className="fas fa-exclamation-triangle text-red-500"></i>
            <p className="text-red-500 text-xs font-bold leading-tight">{error}</p>
          </div>
        )}

        <div className="flex flex-col gap-3">
          <button
            onClick={handleImport}
            disabled={!data.trim()}
            className="w-full py-5 bg-neon text-black font-black uppercase tracking-widest rounded-2xl shadow-xl shadow-neon/20 disabled:opacity-30 disabled:shadow-none active:scale-[0.98] transition-all"
          >
            Create Program
          </button>
          <button
            onClick={useTemplate}
            className="w-full py-4 bg-gray-800 text-gray-400 font-bold uppercase text-xs tracking-widest rounded-2xl hover:text-white transition-colors"
          >
            Load Recommended Program
          </button>
        </div>
      </div>

      <div className="mt-8 p-6 bg-gray-900/30 rounded-3xl border border-gray-800/50">
        <h4 className="text-xs font-black uppercase tracking-widest text-gray-600 mb-3">Parsing Format Tips:</h4>
        <ul className="text-xs text-gray-500 space-y-2 list-disc pl-4">
          <li>Start a new day with <span className="text-gray-300">"Day 1"</span> or <span className="text-gray-300">"Push"</span></li>
          <li>Format exercises: <span className="text-gray-300">Exercise, Sets, Reps</span></li>
          <li>Example: <span className="italic">"Deadlift, 3, 10"</span></li>
          <li>Commas, tabs, or bars (|) work as separators.</li>
        </ul>
      </div>
    </div>
  );
};

export default DataImporter;
