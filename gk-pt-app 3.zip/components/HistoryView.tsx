
import React from 'react';
import { WorkoutSession } from '../types';

interface HistoryViewProps {
  history: WorkoutSession[];
  onBack: () => void;
}

const HistoryView: React.FC<HistoryViewProps> = ({ history, onBack }) => {
  return (
    <div className="flex flex-col p-4 animate-in fade-in slide-in-from-right-4 duration-500">
      <header className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="w-10 h-10 rounded-full bg-surface flex items-center justify-center border border-gray-800 text-white transition-all active:scale-90">
          <i className="fas fa-arrow-left"></i>
        </button>
        <h1 className="text-2xl font-black uppercase tracking-tight italic">Activity <span className="text-neon neon-glow">Log</span></h1>
      </header>

      <div className="flex flex-col gap-6">
        {history.length > 0 ? (
          history.map((session) => (
            <div key={session.id} className="bg-surface border border-gray-800 rounded-2xl overflow-hidden shadow-xl">
              <div className="p-4 bg-gray-900/50 border-b border-gray-800 flex justify-between items-center">
                <div>
                  <h3 className="text-neon font-black uppercase text-xs tracking-widest italic">{session.routineName}</h3>
                  <p className="text-gray-500 text-[10px] font-black uppercase mt-0.5">
                    {new Date(session.date).toLocaleDateString(undefined, { weekday: 'long', month: 'short', day: 'numeric' })}
                  </p>
                </div>
                <div className="text-right">
                  <span className="text-white font-black text-lg">
                    {session.results.reduce((acc, ex) => acc + ex.sets.length, 0)}
                  </span>
                  <span className="text-gray-600 text-[8px] uppercase block font-black leading-none">Sets Total</span>
                </div>
              </div>
              <div className="p-4 space-y-5">
                {session.results.map((ex, idx) => (
                  <div key={idx} className="flex flex-col gap-1.5">
                    <div className="flex justify-between items-start">
                      <p className="text-gray-300 font-black text-xs uppercase italic">{ex.exerciseName}</p>
                      {ex.videoUrl && (
                        <a 
                          href={ex.videoUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-gray-600 hover:text-neon transition-colors"
                        >
                          <i className="fab fa-youtube text-xs"></i>
                        </a>
                      )}
                    </div>
                    <div className="flex flex-wrap gap-1.5">
                      {ex.sets.map((set, sIdx) => (
                        <span key={sIdx} className="text-[9px] font-black bg-black/40 px-2 py-1 rounded text-gray-500 border border-gray-800/50">
                          {set.weight || '0'}kg × {set.reps}
                        </span>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        ) : (
          <div className="text-center py-20 bg-surface/30 rounded-3xl border border-gray-800 border-dashed">
            <i className="fas fa-calendar-alt text-4xl text-gray-800 mb-4"></i>
            <p className="text-gray-500 font-black uppercase text-[10px] tracking-widest">No history recorded</p>
          </div>
        )}
      </div>
    </div>
  );
};

export default HistoryView;
